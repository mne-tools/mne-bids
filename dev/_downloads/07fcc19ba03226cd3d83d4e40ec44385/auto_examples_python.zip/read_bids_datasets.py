"""
.. _read_bids_datasets-example:

==================
Read BIDS datasets
==================

When working with electrophysiological data in the BIDS format, an important
resource is the `OpenNeuro <https://openneuro.org/>`_ database. OpenNeuro
works great with MNE-BIDS because every dataset must pass a validator
that tests to ensure its format meets BIDS specifications before the dataset
can be uploaded, so you know the data will work with a script like in this
example without modification.

We have various data types that can be loaded via the :func:`~mne_bids.read_raw_bids`
function:

- MEG
- EEG (scalp electrodes)
- iEEG (ECoG and SEEG)
- the anatomical MRI scan of a study participant

In this tutorial, we show how :func:`~mne_bids.read_raw_bids` can be used to load and
inspect BIDS-formatted data.
"""  # noqa: D400

# Authors: The MNE-BIDS developers
# SPDX-License-Identifier: BSD-3-Clause

# %%
# Imports
# -------
# We are importing everything we need for this example:

import openneuro
from mne.datasets import sample

from mne_bids import (
    BIDSPath,
    find_matching_paths,
    get_entity_vals,
    make_report,
    print_dir_tree,
    read_raw_bids,
)

# %%
# Download a BIDS dataset from OpenNeuro
# --------------------------------------
#
# A downloaded OpenNeuro dataset is stored in a ``target_dir`` directory, which is
# called the ``root`` of each BIDS dataset. This example uses this
# `EEG dataset <https://openneuro.org/datasets/ds002778>`_ of resting-state recordings
# of patients with Parkinson's disease.
#
# .. note::
#   If the keyword argument ``include`` is omitted, the entire dataset will be
#   downloaded. We're just using data from one subject to reduce the time it takes to
#   run the example.

dataset = "ds002778"
subject = "pd6"

# Create a BIDS root directory in the MNE dataset folder
bids_root = sample.data_path(download=False).parent / dataset
bids_root.mkdir(parents=True, exist_ok=True)

openneuro.download(dataset=dataset, target_dir=bids_root, include=[f"sub-{subject}"])

# %%
# Explore the dataset contents
# ----------------------------
#
# We can use MNE-BIDS to print a tree of all
# included files and folders. We pass the ``max_depth`` parameter to
# :func:`mne_bids.print_dir_tree` to the output to four levels of folders, for
# better readability in this example.

print_dir_tree(bids_root, max_depth=4)

# %%
# We can even ask MNE-BIDS to produce a human-readbale summary report
# on the dataset contents.

print(make_report(bids_root))

# %%
# Now it's time to get ready for reading some of the data! First, we need to
# create an :class:`mne_bids.BIDSPath`, which is the workhorse object of
# MNE-BIDS when it comes to file and folder operations.
#
# For now, we're interested only in the EEG data in the BIDS root directory
# of the Parkinson's disease patient dataset. There were two sessions, one
# where the patients took their regular anti-Parkinsonian medications and
# one where they abstained for more than twelve hours. For now, we are
# not interested in the on-medication session.

sessions = get_entity_vals(bids_root, "session", ignore_sessions="on")
datatype = "eeg"
extensions = [".bdf", ".tsv"]  # ignore .json files
bids_paths = find_matching_paths(
    bids_root, datatypes=datatype, sessions=sessions, extensions=extensions
)

# %%
# We can now retrieve a list of all EEG-related files in the dataset:
print(bids_paths)

# %%
# Note that this is the same as running:
session = "off"
bids_path = BIDSPath(root=bids_root, session=session, datatype=datatype)
print(bids_path.match(ignore_json=True))

# %%
# The returned list contains three paths:
# ``sub-pd6_ses-off_task-rest_channels.tsv``,
# ``sub-pd6_ses-off_task-rest_events.tsv``, and
# ``sub-pd6_ses-off_task-rest_eeg.bdf``.
# The first two are so-called sidecar files that contain information on the
# recording channels and experimental events, and the third one is the actual
# data file.
#
# Prepare reading the data
# ------------------------
#
# There is only one subject (``sub-pd6``) and one experimental task (``rest``).
# Let's use this knowledge to create a new :class:`~mne_bids.BIDSPath` with
# all the information required to actually read the EEG data. We also need to
# pass a ``suffix``, which is the last part of the filename just before the
# extension -- ``"channels"`` and ``"events"`` for the two TSV files in
# our example, and ``"eeg"`` for EEG raw data. For MEG and EEG raw data, the
# suffix is identical to the data type, so don't get confused here!

task = "rest"
suffix = "eeg"

bids_path = bids_path.update(subject=subject, task=task, suffix=suffix)

# %%
# Now let's print the contents of ``bids_path``:

print(bids_path)

# %%
# You probably noticed two things: Firstly, this looks like an ordinary string
# now, not like the more-or-less neatly formatted output we saw before. And
# secondly, there's suddenly a filename extension which we never specified
# anywhere!
#
# The reason is that when you call ``print(bids_path)``, :class:`~mne_bids.BIDSPath`
# returns a string representation of :class:`~mne_bids.BIDSPath.fpath`, which looks
# different. If, instead, you simply typed ``bids_path`` (or ``print(repr(bids_path))``,
# which is the same) into your Python console, you would get the nicely formatted
# output:

bids_path

# %%
# The ``root`` here is – you guessed it – the directory we passed via the
# ``root`` parameter, the "home" of our BIDS dataset. The ``datatype``, again,
# is self-explanatory. The ``basename``, on the other hand, is created
# automatically based on the suffix and **BIDS entities**  we passed to
# :class:`~mne_bids.BIDSPath`; in our case, ``subject``, ``session`` and ``task``.
#
# .. note::
#   There are many more supported entities, the most-commonly used among them
#   probably being ``acquisition``. Please see
#   :ref:`our introduction to BIDSPath <bidspath-example>` to learn more
#   about entities, ``basename``, and ``BIDSPath`` in general.
#
# But what about that filename extension, now? :class:`~mne_bids.BIDSPath.fpath`, which
# - as you hopefully remember – is invoked when you run ``print(bids_path)`` –
# employs some heuristics to auto-detect some missing filename components.
# Omitting the filename extension in your script can make your code
# more portable. Note that, however, you *can* explicitly specify an
# extension too, by passing e.g. ``extension=".bdf"`` to :class:`~mne_bids.BIDSPath`.

# %%
# Read the data
# -------------
#
# Let's read the data! It's just a single line of code:

raw = read_raw_bids(bids_path=bids_path, verbose=False)

# %%
# Notice that a ``RuntimeWarning`` is issued here. This is because some BIDS fields
# (``gender``, ``MMSE``, ``NAART``, ``disease_duration``, ``rl_deficits``, and
# ``notes``) could not be mapped to appropriate MNE metadata fields. You can safely
# ignore this warning as it does not affect the data reading process at all.
#
# Now we can inspect the ``raw`` object to check that it contains to correct metadata.
#
# Basic subject metadata is here:

print(raw.info["subject_info"])

# %%
# Power line frequency is here:

print(raw.info["line_freq"])

# %%
# Sampling frequency is here:

print(raw.info["sfreq"])

# %%
# Events are available as annotations:
print(raw.annotations)

# %%
# Finally, we can plot the resulting raw data:

raw.plot(duration=20, show_scrollbars=False)

# %%
# .. LINKS
#
# .. _parkinsons_eeg_dataset:
#    https://openneuro.org/datasets/ds002778
#
